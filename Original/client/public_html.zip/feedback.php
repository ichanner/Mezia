<?php

?>

<html>
    
    <body>
        <h2>FeedBack!</h2>
        <p> We love our customers and we love improvment!</p>
        <p>Hit us up down below!</p>
          
        <form>
        <input placeholder="Feedback"></input>
        </br>
        <input value="send" type="submit"/>
        </form> 
        
    </body>
    
</html>