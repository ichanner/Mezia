<html>
    
<h3> Welcome to Mezia.net!</h3>
<p><i>Version 2.0 coming soon</i></p>
<a href="https://mezia.net/create">Create a room</a>

</html>
